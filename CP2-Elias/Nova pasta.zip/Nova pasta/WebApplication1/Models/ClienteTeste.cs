﻿namespace WebApplication1.Models
{
    public class ClienteTeste
    {
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
    }
}
